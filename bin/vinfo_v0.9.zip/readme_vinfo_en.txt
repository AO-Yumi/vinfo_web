vinfo - Output audio file-information.

This tool display informations of Vorbis, Opus, OggFLAC
 and MP3, AAC(only ADTS format) files. 

USAGE: vinfo <option> InputFileName

vinfo [return] <--- Display type of options.


---------------------------------------------------------------------------
// CHANGES

Version 0.9 from 0.8.
# Added display of information of MP3 and AAC(ADTS format) files.
# MP3 and AAC(ADTS format): Enabled "-ab" option.
# Opus and OggFLAC: Added display of "Page/Packet Info".
# Opus and OggFLAC: Improved the processing speed. 
# Vorbis: Fixed handling of very small file.
# Fixed method of caluculation of average bitrate in "-ab" option.

Version 0.8 from 0.75.
# Added display of pre/post gap sample value.
# Detect illegal granule position value.
# Added display of information of Opus and OggFLAC files.
# Fixed output format of ".plt" files for the gnuplot version 5.
# Added new "-ab" option. It can output bitrate-information of OggVorbis, Opus and OggFLAC files.
# Correct a memory leak.
# Added detection of 9 new ogg streams.


---------------------------------------------------------------------------
This program is using the following libraries. 
libogg - Copyright (c) 2002-2015 Xiph.org Foundation
libvorbis - Copyright (c) 2002-2015 Xiph.org Foundation


AUTHOR: Aoyumi <aoyumi@gamil.com>
